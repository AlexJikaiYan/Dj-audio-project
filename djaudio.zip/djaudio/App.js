import React, { Component } from 'react';
import { Button, View, Text } from 'react-native';

class Sound1button extends React.Component{
  displayalert(){
    alert("You clicked Sound 1")
  }
  render(){
    return(
      <View>
      <Button title= "sound 1" color="lightblue" onPress={this.displayalert}/>
      </View>
    )
  }
}

class Sound2button extends React.Component{
displayalert(){
  alert("You clicked Sound 2")
}
  render(){
    return(
      <View>
      <Button title="sound 2" color="cyan"onPress={this.displayalert}/>
      </View>
    )
  }
}

class Sound3button extends React.Component{
  displayAlert(){
    alert('You clicked sound 3')
  }
  render(){
   return(
     <View>
    <Button title="sound 3" color=""onPress={this.displayAlert}/>
    </View>
   )
  }
}

class Sound4button extends React.Component{
  displayalert=()=>{
    alert("You clicked sound 4")
  }
  render(){
    return(
      <View>
      <Button title="sound 4" color="blue"onPress={this.displayalert}/>
      </View>
    )
  }
}

class Sound5button extends React.Component{
  displayalert(){
    alert("You clicked Sound 5")
  }
  render(){
    return(
      <View>
      <Button title="sound 5" color="darkblue"onPress={this.displayalert}/>
    </View> 
    )
  }
} 


export default class App extends Component {
  render() {
    return (
      <View>
        <Text style={{marginTop:30}}>Hello welcome to my DJ App, enjoy!</Text>
    <Sound1button/>
    <Sound2button/>
    <Sound3button/>
    <Sound4button/>
    <Sound5button/>
    </View>
    ); 
  }
}



